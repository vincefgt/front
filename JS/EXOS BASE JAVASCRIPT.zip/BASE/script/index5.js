let fibo = [1,10,2,3,5,8];

// affichage
fibo.forEach(num => console.log(num));

// affiche le tabelau comme un tableau
console.table(fibo);

// dernier
fibo.push(13);
// premier
fibo.unshift(0);

// affichage
fibo.forEach(num => console.log(num));

// construction nouveau tableau
let fibo2 = fibo.map(num => num%4);

console.log("fibo2");
fibo2.forEach(num => console.log(num));
console.log("fibo-srt");
fibo.sort();
fibo.forEach(num => console.log(num));

fibo.sort((a,b) => a - b);
fibo.forEach(num => console.log(num));

fibo2.sort((a,b) => a - b);
fibo2.forEach(num => console.log(num));