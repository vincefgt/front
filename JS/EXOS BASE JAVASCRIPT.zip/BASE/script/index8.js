function afficherJour() {
    // Demander la date à l'utilisateur
    const dateStr = prompt("Entrez une date :");

    // Séparer les composants
    const [jour, mois, annee] = dateStr.split("/");

    // Construire la date (mois commence à 0 en JavaScript) YYYY-MM-DD
    const date = new Date(annee, mois - 1, jour);

    const jours = [
        "dimanche", "lundi", "mardi", "mercredi",
        "jeudi", "vendredi", "samedi"
    ];

    // Vérifier validité
    if (isNaN(date.getTime())) {
        console.log("Date invalide !");
        return;
    }



    alert(jours[date.getDay()]);
}

function jourDeLaSemaine() {
    let currentDate = new Date();
 
    let jour = currentDate.getDay();
 
    switch (jour) {
        case 0:
            alert("Dimanche");
            break;
        case 1:
            alert("Lundi");
            break;
        case 2:
            alert("Mardi");
            break;
        case 3:
            alert("Mercredi");
            break;
        case 4:
            alert("Jeudi");
            break;
        case 5:
            alert("Vendredi");
            break;
        case 6:
            alert("Samedi");
            break;
       
    }
 
}

const dayOfWeek1 = () => {
    const date = new Date();
    let options = { weekday: "long" };
    let today = new Intl.DateTimeFormat("fr-FR", options)
        .format(date);
    today = today.charAt(0).toUpperCase() + today.slice(1);
    return today;
}

const dayOfWeek2 = () => {
    const dayNumber = new Date().getDay();
    let msg;
    switch (dayNumber) {
        case 0 : msg = "Dimanche";
            break;
        case 1 : msg = "Lundi";
            break;
        case 2 : msg = "Mardi";
            break;
        case 3 : msg = "Mercredi";
            break;
        case 4: msg = "Jeudi";
            break;
        case 5: msg = "Vendredi";
            break;
        case 6: msg = "Samedi";
            break;
        default: msg = "Jour inconnu";
    }
    return msg;
}