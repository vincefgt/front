let a=3;
let b=2;

function multiplie(x=8) {
    return x*3;
}

function affiche() {

    alert("multiplie de a : " + multiplie(a));
    alert("multiplie de b : " + multiplie(b));
    alert("multiplie par défaut : " + multiplie());
}