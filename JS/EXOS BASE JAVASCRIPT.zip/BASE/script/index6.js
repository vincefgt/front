function boucle(x=3) {

    let tab = new Array(x);
    for(let i=0; i<x; i++) {
        tab[i] = Math.pow(i, 2);
    }

    console.table(tab);

}

function boucle2() {

    let x = prompt("Longueur ud tableau ?");
    boucle(x);
}