let largeur = 0;
let longueur = 0;
let result = 0;

function surface() {
    saisie();
    result = largeur * longueur;
    affiche("La surface est de ");
}

function perimetre() {
    saisie();
    result = (largeur+largeur)*2;
    affiche("Le perimétre est de ");
}

function saisie() {
    largeur = prompt("donner la largeur ?");
    longueur = prompt("donner la longueur ?");
}

function affiche(message) {
    alert(message + result);
}

document.addEventListener("DOMContentLoaded", (event) => {
  document.getElementById("button").addEventListener("click", surface);
});