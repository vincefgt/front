function surface() {

    let rayon = prompt("Donner le rayon ?");
    let result = Math.PI * Math.pow(rayon, 2);
    alert("la surface du cercle est " + result + " cm2");

}

//document.getElementById("button").addEventListener("click", surface());