let tab = [-2, 1, 4];

function addition(x) {
    return x+2;
}

function affiche() {
    alert("1er element : " + addition(tab[0]));
    alert("dernier element : " + addition(tab[tab.length-1]));
}